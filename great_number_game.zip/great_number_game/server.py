from flask import Flask, render_template, redirect, session, request
import random

number_game = Flask(__name__)
number_game.secret_key = "ThisIsSecret"
number_game.number = str(random.randrange(0,101))
number_game.guess = None


@number_game.route('/')
def index():
	session['number'] = number_game.number
	print "guess", session['guess']
	print "number", session['number']
	return render_template("index.html")

@number_game.route('/input', methods=['POST'])
def input():
	session['guess'] = request.form['input']
	return redirect('/')

@number_game.route('/reset', methods=['POST'])
def reset():
	number_game.guess == None
	number_game.number = str(random.randrange(0,101))
	session['guess'] = number_game.guess
	return redirect('/')

number_game.run(debug=True)